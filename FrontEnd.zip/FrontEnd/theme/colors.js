export default {
  primary: '#F4A261',
  secondary: '#2A9D8F',
  background: '#FFFFFF',
  text: '#264653'
};