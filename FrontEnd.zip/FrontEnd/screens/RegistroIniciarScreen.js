import React, { useState } from 'react';
import { 
  View, TextInput, Button, Alert, Text, StyleSheet, TouchableOpacity 
} from 'react-native';
import colors from '../theme/colors';
import { iniciarRegistro } from '../api/auth';

export default function RegistroIniciarScreen({ navigation }) {
  const [mail, setMail] = useState('');
  const [nickname, setNickname] = useState('');
  const [loading, setLoading] = useState(false);

  const handleIniciar = async () => {
    if (!mail || !nickname) {
      return Alert.alert('Error', 'Debes completar correo y alias.');
    }
    setLoading(true);
    try {
      await iniciarRegistro({ mail, nickname });
      Alert.alert(
        'Registro iniciado',
        'Revisa tu correo para el código de validación.',
        [{ text: 'Continuar', onPress: () => 
            navigation.navigate('RegistroFinal', { mail }) 
        }]
      );
    } catch (err) {
      Alert.alert('Error', err.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Crear cuenta</Text>
      <TextInput
        placeholder="Correo electrónico"
        value={mail}
        onChangeText={setMail}
        autoCapitalize="none"
        keyboardType="email-address"
        style={styles.input}
      />
      <TextInput
        placeholder="Alias"
        value={nickname}
        onChangeText={setNickname}
        autoCapitalize="none"
        style={styles.input}
      />
      <TouchableOpacity 
        onPress={handleIniciar} 
        style={[styles.button, loading && styles.buttonDisabled]}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Enviando...' : 'Iniciar registro'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 24,
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 32,
    textAlign: 'center',
  },
  input: {
    height: 50,
    borderColor: colors.text,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    marginBottom: 16,
    color: colors.text,
  },
  button: {
    height: 50,
    backgroundColor: colors.primary,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    backgroundColor: colors.secondary,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
