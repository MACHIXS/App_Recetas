package ar.uade.edu.apprecetas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRecetasApplicationTests {

	@Test
	void contextLoads() {
	}

}
