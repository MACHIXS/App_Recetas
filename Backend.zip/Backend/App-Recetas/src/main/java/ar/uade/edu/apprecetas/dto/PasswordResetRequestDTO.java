package ar.uade.edu.apprecetas.dto;

import lombok.Data;

@Data
public class PasswordResetRequestDTO {
    private String mail;
}
