package ar.uade.edu.apprecetas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppRecetasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppRecetasApplication.class, args);
	}

}
