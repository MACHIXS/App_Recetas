package ar.uade.edu.apprecetas.dto;

import lombok.Data;


@Data
public class RegistroInicioDTO {
    private String mail;
    private String nickname;

}