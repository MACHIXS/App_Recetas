package ar.uade.edu.apprecetas.controller;

import ar.uade.edu.apprecetas.dto.RecetaDto;
import ar.uade.edu.apprecetas.service.ListaService;
import ar.uade.edu.apprecetas.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lista")
public class ListaController {
    private final ListaService listaService;
    private final JwtUtil jwtUtil;

    public ListaController(ListaService ls, JwtUtil ju) {
        this.listaService = ls;
        this.jwtUtil = ju;
    }

    private String mailDe(String auth) {
        return jwtUtil.extractMail(auth.substring(7));
    }

    @PostMapping("/{idReceta}")
    public ResponseEntity<Void> agregar(
            @RequestHeader("Authorization") String auth,
            @PathVariable Integer idReceta) {
        listaService.agregar(mailDe(auth), idReceta);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{idReceta}")
    public ResponseEntity<Void> eliminar(
            @RequestHeader("Authorization") String auth,
            @PathVariable Integer idReceta) {
        listaService.eliminar(mailDe(auth), idReceta);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public List<RecetaDto> listar(
            @RequestHeader("Authorization") String auth) {
        return listaService.listar(mailDe(auth));
    }
}
