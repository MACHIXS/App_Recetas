package ar.uade.edu.apprecetas.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "cronogramas")
public class Cronograma {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCronograma;

    private LocalDate fechaInicio;
    private LocalDate fechaFin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idCurso", nullable = false)
    private Curso curso;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idSede", nullable = false)
    private Sede sede;

    private Integer vacantesDisponibles;

    // getters/setters
    public Integer getIdCronograma() { return idCronograma; }
    public void setIdCronograma(Integer id) { this.idCronograma = id; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate f) { this.fechaInicio = f; }
    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate f) { this.fechaFin = f; }
    public Curso getCurso() { return curso; }
    public void setCurso(Curso c) { this.curso = c; }
    public Sede getSede() { return sede; }
    public void setSede(Sede s) { this.sede = s; }
    public Integer getVacantesDisponibles() { return vacantesDisponibles; }
    public void setVacantesDisponibles(Integer v) { this.vacantesDisponibles = v; }
}
