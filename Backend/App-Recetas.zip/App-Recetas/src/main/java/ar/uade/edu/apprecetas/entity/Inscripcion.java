// src/main/java/ar/uade/edu/apprecetas/entity/Inscripcion.java
package ar.uade.edu.apprecetas.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "inscripciones")
public class Inscripcion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAsistencia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idAlumno", nullable = false)
    private Alumno alumno;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idCronograma", nullable = false)
    private Cronograma cronograma;

    private LocalDateTime fecha;
    private BigDecimal monto;

    // getters/setters
    public Integer getIdAsistencia() { return idAsistencia; }
    public void setIdAsistencia(Integer id) { this.idAsistencia = id; }
    public Alumno getAlumno() { return alumno; }
    public void setAlumno(Alumno a) { this.alumno = a; }
    public Cronograma getCronograma() { return cronograma; }
    public void setCronograma(Cronograma c) { this.cronograma = c; }
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime f) { this.fecha = f; }
    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal m) { this.monto = m; }
}
