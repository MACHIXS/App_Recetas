package ar.uade.edu.apprecetas.repository;

import ar.uade.edu.apprecetas.entity.TipoReceta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoRecetaRepository extends JpaRepository<TipoReceta, Integer> {}

