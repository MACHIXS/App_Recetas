package ar.uade.edu.apprecetas.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CalificarDTO {
    private int calificacion;
    private String comentarios;
}
