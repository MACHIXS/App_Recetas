package ar.uade.edu.apprecetas.controller;

import ar.uade.edu.apprecetas.entity.Inscripcion;
import ar.uade.edu.apprecetas.security.JwtUtil;
import ar.uade.edu.apprecetas.service.InscripcionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inscripciones")
public class InscripcionController {

    @Autowired private InscripcionService inscripcionService;
    @Autowired private JwtUtil jwtUtil;
/*
    @PostMapping("/{idCronogramaCurso}")
    @PreAuthorize("hasRole('ALUMNO')")
    public ResponseEntity<Void> inscribir(
            @RequestHeader("Authorization") String auth,
            @PathVariable Integer idCronogramaCurso) {

        String mail = jwtUtil.extractMail(auth.substring(7));
        inscripcionService.inscribirAlumno(mail, idCronogramaCurso);
        return ResponseEntity.ok().build();
    }

 */

    @DeleteMapping("/{idAsistencia}")
    public ResponseEntity<Void> cancelar(
            @RequestHeader("Authorization") String auth,
            @PathVariable Integer idAsistencia,
            @RequestParam(defaultValue = "false") boolean usarCuentaCorriente) {

        String mail = jwtUtil.extractMail(auth.substring(7));
        inscripcionService.cancelarInscripcion(mail, idAsistencia, usarCuentaCorriente);
        return ResponseEntity.ok().build();
    }
}
