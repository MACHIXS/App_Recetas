package ar.uade.edu.apprecetas.service;


import ar.uade.edu.apprecetas.dto.RecetaDto;
import ar.uade.edu.apprecetas.entity.ListaReceta;
import ar.uade.edu.apprecetas.entity.Receta;
import ar.uade.edu.apprecetas.entity.Usuario;
import ar.uade.edu.apprecetas.entity.Calificacion;
import ar.uade.edu.apprecetas.repository.ListaRecetaRepository;
import ar.uade.edu.apprecetas.repository.RecetaRepository;
import ar.uade.edu.apprecetas.repository.UsuarioRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ListaService {
    private final ListaRecetaRepository listaRepo;
    private final UsuarioRepository usuarioRepo;
    private final RecetaRepository recetaRepo;

    public ListaService(ListaRecetaRepository lr,
                        UsuarioRepository ur,
                        RecetaRepository rr) {
        this.listaRepo = lr;
        this.usuarioRepo = ur;
        this.recetaRepo = rr;
    }

    @Transactional
    public void agregar(String mail, Integer idReceta) {
        if (!listaRepo.existsByUsuario_MailAndReceta_IdReceta(mail,idReceta)) {
            Usuario u = usuarioRepo.findByMail(mail)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
            Receta r = recetaRepo.findById(idReceta)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
            var lr = new ListaReceta();
            lr.setUsuario(u);
            lr.setReceta(r);
            listaRepo.save(lr);
        }
    }

    @Transactional
    public void eliminar(String mail, Integer idReceta) {
        listaRepo.deleteByUsuario_MailAndReceta_IdReceta(mail,idReceta);
    }

    public List<RecetaDto> listar(String mail) {
        return listaRepo.findByUsuario_Mail(mail)
                .stream()
                .map(lr -> toDto(lr.getReceta()))
                .collect(Collectors.toList());
    }

    private RecetaDto toDto(Receta r) {
        // reutiliza tu mapeo existente
        double avg = r.getCalificaciones().stream()
                .mapToInt(Calificacion::getCalificacion).average().orElse(0);
        return new RecetaDto(
                r.getIdReceta(),
                r.getNombreReceta(),
                r.getFotoPrincipal(),
                r.getUsuario().getNickname(),
                avg,
                r.getTipo().getIdTipo(),
                r.getFechaCreacion()
        );
    }
}
