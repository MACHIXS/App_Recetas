package ar.uade.edu.apprecetas.service;

import ar.uade.edu.apprecetas.entity.*;
import ar.uade.edu.apprecetas.repository.AlumnoRepository;
import ar.uade.edu.apprecetas.repository.InscripcionRepository;
import ar.uade.edu.apprecetas.repository.UsuarioRepository;
import ar.uade.edu.apprecetas.repository.CronogramaRepository; // << esto
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Service
public class InscripcionService {

    @Autowired private InscripcionRepository insRepo;
    @Autowired private UsuarioRepository     usuarioRepo;
    @Autowired private CronogramaRepository  cronRepo;      // << CronogramaRepository
    @Autowired private AlumnoRepository alumnoRepo;
    @Autowired private EmailService          emailService;

    /**
     * Inscribe al usuario y manda mail de confirmación.
     */
    public void inscribirAlumno(String mailUsuario, Integer idCronograma) {
        // 1) Recupero usuario
        Usuario usuario = usuarioRepo.findByMail(mailUsuario)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED, "Usuario no encontrado"));

        // 2) Recupero cronograma
        Cronograma cron = cronRepo.findById(idCronograma)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Cronograma no encontrado"));

        // 3) Creo y guardo la inscripción
        Inscripcion ins = new Inscripcion();
        ins.setAlumno(ins.getAlumno());
        ins.setCronograma(cron);
        insRepo.save(ins);

        // 4) Envío mail sencillo
        String nombreCurso = cron.getCurso().getDescripcion(); // ajusta según tu getter
        emailService.enviarInscripcionExitosa(usuario.getMail(), nombreCurso);
    }

    @Transactional
    public void cancelarInscripcion(String mailUsuario,
                                    Integer idAsistencia,
                                    boolean usarCuentaCorriente) {
        Inscripcion ins = insRepo.findById(idAsistencia)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Inscripción no encontrada"));

        // 1) Aseguramos que quien pide cancelar es el alumno o un ADMIN
        Alumno alumno = ins.getAlumno();  // << directamente el Alumno
        if (!alumno.getUsuario().getMail().equals(mailUsuario)
            /* && no es admin... */) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }

        // 2) Calculo días hábiles
        LocalDate inicio = ins.getCronograma().getFechaInicio();
        LocalDate hoy    = LocalDate.now();
        long diasHabiles = countBusinessDays(hoy, inicio);

        // 3) Defino % de reintegro
        BigDecimal porcentaje;
        if (hoy.isAfter(inicio))               porcentaje = BigDecimal.ZERO;
        else if (diasHabiles >= 10)            porcentaje = BigDecimal.ONE;
        else if (diasHabiles >= 1)             porcentaje = new BigDecimal("0.7");
        else                                    porcentaje = new BigDecimal("0.5");

        // 4) Monto a devolver
        BigDecimal montoReintegro = ins.getMonto().multiply(porcentaje);

        // 5) Proceso reintegro
        if (porcentaje.compareTo(BigDecimal.ZERO) > 0) {
            if (usarCuentaCorriente) {
                // **Usamos AlumnoRepository para guardar la cuenta corriente**
                alumno.setCuentaCorriente(alumno.getCuentaCorriente().add(montoReintegro));
                alumnoRepo.save(alumno);
            } else {
                // aquí harías tu refund real
            }
        }

        // 6) Borro la inscripción
        insRepo.delete(ins);

        // 7) Notifico al alumno
        emailService.enviarCancelacion(
                alumno.getUsuario().getMail(),
                ins.getCronograma().getCurso().getDescripcion(),
                montoReintegro,
                porcentaje.multiply(new BigDecimal("100")).intValue()
        );
    }

    private long countBusinessDays(LocalDate startInclusive, LocalDate endExclusive) {
        long days = ChronoUnit.DAYS.between(startInclusive, endExclusive);
        long result = 0;
        for (int i = 1; i <= days; i++) {
            DayOfWeek d = startInclusive.plusDays(i).getDayOfWeek();
            if (d != DayOfWeek.SATURDAY && d != DayOfWeek.SUNDAY) result++;
        }
        return result;
    }
}

