package ar.uade.edu.apprecetas.repository;

import ar.uade.edu.apprecetas.entity.ListaReceta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ListaRecetaRepository extends JpaRepository<ListaReceta,Integer> {
    boolean existsByUsuario_MailAndReceta_IdReceta(String mail, Integer idReceta);
    List<ListaReceta> findByUsuario_Mail(String mail);
    void deleteByUsuario_MailAndReceta_IdReceta(String mail, Integer idReceta);
}
