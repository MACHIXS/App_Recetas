package ar.uade.edu.apprecetas.entity;

public enum EstadoReceta{
    PENDIENTE,
    APROBADA
}
