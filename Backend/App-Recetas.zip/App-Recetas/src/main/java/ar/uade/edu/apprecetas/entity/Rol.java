package ar.uade.edu.apprecetas.entity;


public enum Rol {
    USER,
    ADMIN,
}

